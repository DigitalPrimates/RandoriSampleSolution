﻿using SharpKit.Html;
using SharpKit.JavaScript;
using SharpKit.jQuery;

namespace $rootnamespace$ {
    public class $safeitemrootname$ {
        public $safeitemrootname$() {
        }
    }
}